# Roblox Aircraft Carrier

A Roblox Studio aircraft carrier project built with Luau, including procedural construction and interactive ship systems.

## Source layout
- `src/server/CarrierBuilder.server.luau` — procedural carrier construction
- `src/server/CarrierDoors.server.luau` — interactive doors
- `src/server/CarrierElevator.server.luau` — aircraft elevators

**Source import pending:** These three scripts must be added from the latest owner-approved versions. The workspace ZIP contains no placeholder Luau implementations.

## AI collaboration
Read [AGENTS.md](AGENTS.md) before editing. Review architecture and known issues in `docs/`. Use GitHub branches/pull requests for substantial changes.

## Roblox Studio
The scripts are intended for server-side execution. Confirm the expected placement, names, and dependency order from the actual source before importing or running them. Test changes in Roblox Studio; static review cannot validate physics and animations.

## Status
Repository workspace scaffold prepared; gameplay code not included.
