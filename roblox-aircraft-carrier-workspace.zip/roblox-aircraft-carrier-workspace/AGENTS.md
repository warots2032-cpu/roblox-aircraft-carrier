# AI Agent Instructions — Roblox Aircraft Carrier

## Purpose
This GitHub repository is the canonical source for the Roblox aircraft carrier project. ChatGPT, Claude, and Codex should read this file and README.md before proposing edits.

## Rules
- Preserve geometry, dimensions, appearance, interior layout, decorative details, and intended functionality unless the owner approves a change.
- Do not remove visual details merely to improve performance.
- Review dependencies among CarrierBuilder, CarrierDoors, and CarrierElevator before editing.
- Preserve instance names, attributes, interfaces, and initialization assumptions unless an approved change requires otherwise.
- Do not invent Roblox APIs or claim runtime tests were performed without evidence.
- Inspect the latest commit before writing; avoid overwriting another agent's changes.
- Prefer small feature branches and reviewable pull requests; obtain owner approval before merging.
- Never commit secrets, credentials, or authentication tokens.

## Workflow
1. Read README.md, docs/ARCHITECTURE.md, docs/KNOWN_ISSUES.md, and relevant source files.
2. Separate confirmed source defects, suspected runtime defects, and optional improvements.
3. Explain proposed fixes and regression risks before substantial rewrites.
4. Implement approved changes in small, focused patches.
5. Record meaningful changes in CHANGELOG.md.
6. Provide Roblox Studio verification steps, clearly separating static inspection from runtime testing.

## Current focus
Investigate passageway doors that start open and decorations that appear rotated or displaced approximately 90 degrees. Verify closed/open CFrames, decoration offsets, and weld creation order. Do not assume the issue remains in newer scripts without checking.

## Expected source paths
- src/server/CarrierBuilder.server.luau
- src/server/CarrierDoors.server.luau
- src/server/CarrierElevator.server.luau

The actual Luau source has not yet been imported. Never fabricate replacements for missing code.

## Collaboration
GitHub is the shared workspace, not the chat transcript. Each AI tool requires its own authorized repository access; connecting ChatGPT does not automatically connect Claude.
