# Changelog

## Unreleased
- Prepared shared GitHub workspace documentation and AI agent instructions.
- Documented initial issue hypotheses and Roblox Studio testing checklist.
- Gameplay script import pending; no gameplay code has been modified.
