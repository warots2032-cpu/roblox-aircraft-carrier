# Known Issues and Investigation Queue

## Passageway doors and decorations
**Status:** Unverified against latest scripts.

Reported: Some doors start open, while decorations appear rotated or displaced about 90 degrees and move with an incorrect offset.

Hypothesis: Door leaves may be initially placed at an open transform while decorations are placed relative to a closed transform before welding. Inspect construction order and relative CFrames; do not assume the hypothesis is proven.

Acceptance criteria:
- Doors configured closed spawn closed.
- Intentionally open doors display correctly.
- Handwheels and other details align when closed and remain aligned throughout motion.
- Repeated opening and closing works without regression.

## Elevator and hangar door coordination
**Status:** Requires code inspection and Studio testing.

Check whether elevator movement waits for a safe hangar-door state, and whether timeout or reversal paths leave inconsistent states.

## Performance
**Status:** Not profiled.

Measure representative server/client performance before changing part counts or physics constraints. Preserve visual fidelity.
