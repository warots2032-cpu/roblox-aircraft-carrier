# Architecture

## Systems (high-level, pending source verification)

### CarrierBuilder
Procedurally creates the carrier hull, flight deck, interiors, doors, and visual details.

### CarrierDoors
Manages interactive door states and movement, including passageway and hangar doors.

### CarrierElevator
Manages aircraft elevator movement, player interaction, and possible hangar-door coordination.

## Contracts to verify from actual scripts
- Generated instance hierarchy and names
- Shared attributes and command/state semantics
- Closed and open CFrame conventions
- Weld creation and decoration attachment order
- Constraints and movement behavior on a mobile ship
- Elevator/hangar-door completion acknowledgement and timeouts

## Runtime
Roblox Studio testing is required for physical motion, networking, and interaction. This document is not a verified API specification until the source is imported and reviewed.
