# Roblox Studio Testing Checklist

Record test date, Studio version, Git commit, tester, and results.

- [ ] Builder completes without errors.
- [ ] Hull, flight deck, island, hangar, and interiors are visually correct.
- [ ] Closed passageway doors spawn closed.
- [ ] Initially open doors and their decorations align correctly.
- [ ] Handwheels, latches, and details stay aligned while doors animate.
- [ ] Repeated door interactions do not create conflicting animations.
- [ ] Hangar doors open and close correctly.
- [ ] Elevators move to expected levels and report correct states.
- [ ] Elevator/hangar door synchronization behaves safely.
- [ ] Multiplayer interactions do not corrupt state.
- [ ] Server output has no unexpected errors or warnings.
- [ ] Performance is measured with the complete carrier loaded.
