# Import the actual Luau scripts here

Add the latest owner-approved scripts under these names:

- CarrierBuilder.server.luau
- CarrierDoors.server.luau
- CarrierElevator.server.luau

This folder intentionally contains no invented or placeholder gameplay code. Remove this note after importing the scripts if desired.
